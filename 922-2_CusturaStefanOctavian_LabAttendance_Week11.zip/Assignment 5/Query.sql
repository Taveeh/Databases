DROP TABLE Enrollment
DROP TABLE Students
DROP TABLE Course
CREATE TABLE Students ( -- Ta
    StudentID INT PRIMARY KEY IDENTITY , -- aid
    Name VARCHAR(50),
    PhoneNumber INT UNIQUE, -- a2
    StudentGroup INT
)
CREATE TABLE Course ( -- Tb
    CourseID INT PRIMARY KEY IDENTITY , -- bid
    Title VARCHAR(50),
    NumberOfCredits INT -- b2
)
CREATE TABLE Enrollment ( -- Tc
    Student INT REFERENCES Students(StudentID), -- aid
    Course INT REFERENCES Course(CourseID), -- bid
    EntollmentID INT PRIMARY KEY IDENTITY -- cid
)

INSERT INTO Students(Name, PhoneNumber, StudentGroup)
	VALUES
		('Student 1', 1, 1),
		('Student 2', 2, 1),
		('Student 3', 3, 1),
		('Student 4', 4, 2),
		('Student 5', 5, 2),
		('Student 6', 6, 2),
		('Student 7', 7, 3),
		('Student 8', 8, 3),
		('Student 9', 9, 3)

INSERT INTO Course(Title, NumberOfCredits)
	VALUES
		('MAP', 6),
		('DB', 6),
		('PLF', 6),
	    ('PS', 6),
        ('English', 3),
	    ('CompNet', 6)

INSERT INTO Enrollment(Student, Course)
	VALUES
		(1, 1),
		(2, 6),
		(3, 1),
		(4, 3),
		(5, 3),
		(6, 4),
		(7, 2),
		(8, 1),
		(9, 5)

SELECT * FROM Students
SELECT * FROM Course
SELECT * FROM Enrollment


-- a. Clustered index scan
SELECT * FROM Students ORDER BY StudentID

-- b. Clustered index seek
SELECT * FROM Students WHERE StudentID > 2
